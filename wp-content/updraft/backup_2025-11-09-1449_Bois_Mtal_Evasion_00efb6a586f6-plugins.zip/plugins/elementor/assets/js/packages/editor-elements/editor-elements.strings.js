__( 'Item removed', 'elementor' );
__( 'Item duplicated', 'elementor' );
__( 'Item added', 'elementor' );