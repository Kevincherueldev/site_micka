<?php
declare( strict_types = 1 );

// Silence is golden.
